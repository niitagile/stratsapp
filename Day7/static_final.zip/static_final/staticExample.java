package static_final;
class Student{
	String name;
	static String course;
	void display(){
		System.out.println(name);
		System.out.println(course);
	}
	static void getInfo(){
		//name="Babita";non-sataic variable
		course="Btech";
	}
}
public class staticExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student obj=new Student();
		obj.display();
		Student.getInfo();

	}

}
