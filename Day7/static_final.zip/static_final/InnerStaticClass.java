package static_final;
class Outer{
	int num=89;
	
	static class Inner{
		String course="Btech";
		void display(){
			System.out.println(course);
			//System.out.println(num);non-static
		}
	}
	
}
public class InnerStaticClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Outer.Inner outer=new Outer.Inner();
		outer.display();
	}

}
