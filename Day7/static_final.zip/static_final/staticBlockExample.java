package static_final;
class Test{
	static{
		System.out.println("static block");
	}
	{
		System.out.println("non-static block");
	}
	Test(){
		System.out.println("Constructor");
	}
}
public class staticBlockExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test t=new Test();
		Test t1=new Test();
	}

}
