package UserController;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.User;
import DAO.UserDao;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDao userDao;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		userDao=new UserDao();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
			String action=request.getServletPath();
			try{
				switch(action){
				case "/new" :
					showNewForm(request,response);
					break;
				case "/insert":
					insertUser(request,response);
					break;
				case "/delete":
					deleteUser(request,response);
					break;
				case "/edit":
					showEditForm(request,response);
					break;
				case "/update":
					updateUser(request,response);
					break;
				default:
						listUser(request,response);
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
	
	}

	private void updateUser(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, SQLException, IOException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("id"));
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String country=request.getParameter("country");
		User user=new User(id,name,email,country);
		userDao.updateUser(user);
		response.sendRedirect("list");
		
	}

	private void showEditForm(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("id"));
		User existingUser=userDao.selectUser(id);
		RequestDispatcher rd=request.getRequestDispatcher("user-form.jsp");
		request.setAttribute("user",existingUser);
		rd.forward(request, response);
		
		
		
	}

	private void deleteUser(HttpServletRequest request,
			HttpServletResponse response)throws ServletException,SQLException, IOException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("id"));
		userDao.deleteuser(id);
		response.sendRedirect("list");
		
		
	}

	private void insertUser(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String country=request.getParameter("country");
		User newUser=new User(name,email,country);
		userDao.insertUser(newUser);
		response.sendRedirect("list");
		
		
	}

	private void showNewForm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException{
		// TODO Auto-generated method stub
		RequestDispatcher rd=request.getRequestDispatcher("user-form.jsp");
		rd.forward(request, response);
		
	}

	private void listUser(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException{
		// TODO Auto-generated method stub
		List <User> listUser=userDao.selectAllUsers();
		request.setAttribute("listUser", listUser);
		RequestDispatcher dispatcher =request.getRequestDispatcher("list-user.jsp");
		dispatcher.forward(request,response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request,response);
	}

}
