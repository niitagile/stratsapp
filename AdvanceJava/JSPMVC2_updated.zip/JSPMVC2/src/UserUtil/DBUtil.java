package UserUtil;

import java.sql.Connection;
import java.sql.DriverManager;


public class DBUtil {
	
public static Connection getDBConn()
{
	Connection con=null;
	//write code here
	try{
		//Class.forName("oracle.jdbc.OracleDriver");
		Class.forName("oracle.jdbc.driver.OracleDriver");
	if(con==null)
		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","B202002202002006","B202002202002006");
	}catch(Exception e){
		e.printStackTrace();
	}
		return con;
}
}
/* conn / as sysdba
Connected.
SQL> create user B202002202002006 identified by B202002202002006;

User created.

SQL> grant connect, resource to B202002202002006;

Grant succeeded.

SQL> alter user B202002202002006 default tablespace users quota unlimited on users;

User altered.

SQL> conn B202002202002006/B202002202002006
Connected.*/
/*create Sequence CANDID_SEQ
2  MinValue 5000
3  MaxValue 7000
4  Increment By 1
5* Start with 5000
*/
/*
create table CANDIDATE_TBL(
ID Varchar2(6) Primary Key,
Name Varchar2(15),
M1 Number(3),
M2 Number(3),
M3 Number(3),
Result Varchar2(15)
Grade Varchar2(15)
);
*/