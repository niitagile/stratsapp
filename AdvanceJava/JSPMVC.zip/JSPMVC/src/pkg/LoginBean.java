package pkg;

import java.io.Serializable;

public class LoginBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String Uname,pword;

	public String getUname() {
		return Uname;
	}

	public void setUname(String uname) {
		Uname = uname;
	}

	public String getPword() {
		return pword;
	}

	public void setPword(String pword) {
		this.pword = pword;
	}

	public LoginBean() {
		super();
	}
	public boolean validate(){
		if(Uname.equalsIgnoreCase("java") && pword.equals("abc123"))
		return true;	
		
		return false;
		
	}
}
