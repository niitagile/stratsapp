package pkg;
import java.sql.*;
import java.sql.PreparedStatement;

public class LoginDao {
	public boolean authenticateUser(LoginBean bean){
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		boolean result=false;
		try{
			con=DBConnection.getConnection();
			String query="select * from login where userid=? and password=?";
			ps=con.prepareStatement(query);
			ps.setString(1, bean.getUname());
			ps.setString(2,bean.getPword());
			rs=ps.executeQuery();
			result=rs.next();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}

}
