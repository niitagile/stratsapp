import java.util.Scanner;
import java.lang.String;//Optional

class Product{
	int pid;
	String pname;
	int qty, price;
	public Product(int pid, String pname, int qty, int price) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.qty = qty;
		this.price = price;
	}
	//private means it cannot be accessed outside the class
	private int bill(){
		return qty*price;
	}
	void changeValues(){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter new price");
		price=scan.nextInt();
	}
	void show(){
		System.out.println("product id="+pid);
		System.out.println("Total Amount="+bill());
	}
}
public class ProductDetails {

	public static void main(String[] args) {
		Product obj=new Product(1,"Sugar",5,30);
		System.out.println("Old Values");
		obj.show();
		
		obj.changeValues();
		System.out.println("New Values");
		obj.show();
		Product obj1=new Product(2,"Salt",2,20);
		System.out.println("Values of II Object");
		obj1.show();

	}

}
