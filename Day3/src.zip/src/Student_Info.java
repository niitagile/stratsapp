import java.util.Scanner;

class StudentData{
	int rollno;
	String name;
	int maths, eng, hindi,total;
	char grade;
	void getInfo(){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter rollno");
		rollno=scan.nextInt();
		scan.nextLine();
		System.out.println("Enter name");
		name=scan.nextLine();
		System.out.println("Enter maths,eng,hindi");
		maths=scan.nextInt();
		eng=scan.nextInt();
		hindi=scan.nextInt();
	}
	// when method is not returning any value use void
	/*if(condition){
	 * statements;
	 * }
	 * else
	 * {
	 * 
	 * }
	 * 
	 * 
	 */
	void calc(){
		total=maths+eng+hindi;
		if(total>=80)
			grade='A';
		else if(total>=60)
			grade='B';
		else if(total >=40)
			grade='C';
		else
			grade='F';
	}
	
	void show(){
		System.out.println("Rollno="+rollno);
		System.out.println("name="+name);
		System.out.println("total="+total);
		System.out.println("grage="+grade);
	}
	
	
}
public class Student_Info {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentData stud=new StudentData();
		stud.getInfo();
		stud.calc();
		stud.show();

	}

}
