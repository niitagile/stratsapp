import java.util.Scanner;

class ShowRoom{
	int mill_cloth_qty;
	int handloom_cloth_qty;
	final float mill_cloth_price=78.5f;
	final float handloom_cloth_price=78.5f;
	void getQty(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter qty for mill cloth");
		mill_cloth_qty=sc.nextInt();
		System.out.println("Enter qty for handloom cloth");
		handloom_cloth_qty=sc.nextInt();
	}
	double calcFinalAmount(){
		double final_amount=0;
		float mill_p_amount=(mill_cloth_price*mill_cloth_qty);
		float handloom_p_amount=(handloom_cloth_price*handloom_cloth_qty);
		final_amount=mill_p_amount+handloom_p_amount;
		if(final_amount>300){
			final_amount=mill_p_amount-(mill_p_amount*.1)+handloom_p_amount-(handloom_p_amount*.15);
		}
		else if (final_amount >=300)
			final_amount=mill_p_amount-(mill_p_amount*.075)+handloom_p_amount-(handloom_p_amount*.1);
		else if (final_amount >=200)
			final_amount=mill_p_amount-(mill_p_amount*.075)+handloom_p_amount-(handloom_p_amount*.1);
		else if (final_amount >=100)
			final_amount=mill_p_amount-(mill_p_amount*.05)+handloom_p_amount-(handloom_p_amount*.075);
		else
			final_amount=mill_p_amount+handloom_p_amount-(handloom_p_amount*.05);
		return final_amount;
	}
	void display(){
		System.out.println("Your bill is "+calcFinalAmount());
		
	}
}
public class Assignment1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			ShowRoom user1=new ShowRoom();
			user1.getQty();
			user1.display();
	}

}
