import java.util.Scanner;


public class Demo {
	public static void main(String[] args) {
		
		
		//take values from user and calculate average
			Scanner scan =new Scanner(System.in);
			int num,total=0,count=0;
			float avg=0;
			String ans;
		do{
				System.out.println("Enter a value"+count);
				num=scan.nextInt();
				total=total+num;
				count++;
				
				System.out.println("Do you want to enter next value(Y/N");
				ans=scan.next();
				
			}while(ans.equals("Y")||ans.equals("y"));

			avg=total/count;
			System.out.println(avg);
				
	}

}
 