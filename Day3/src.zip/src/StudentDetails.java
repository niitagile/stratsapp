
public class StudentDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Student stud1=new Student(1,"Ritu",89.5f);
			stud1.display();
			Student stud2=new Student(2, "Nisha", 76.5f);
			stud2.display();
	}

}
