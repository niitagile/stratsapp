class Person{}
public class instanceofExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			String name="Nidhi";
			Student stud =new Student();
			System.out.println(name instanceof String);
			System.out.println(name instanceof Object);
			System.out.println(stud instanceof Student);
			System.out.println(stud instanceof Object);
	}

}
