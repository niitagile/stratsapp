
public class Student {
	int rollno;
	String name;
	float total;
	
	public Student() {
		rollno=0;
		name=null;
		total=0.0f;
	}

	public Student(int rollno, String name, float total) {
		
		this.rollno = rollno;
		this.name = name;
		this.total = total;
	}

	void display(){
		System.out.println("rollno="+rollno);
		System.out.println("name="+name);
		System.out.println("total="+total);
		
	}

}
