class Student1 {
	int rollno;//instance variable
	String name;
	float total;
	
	
//local variables always get priory over instance variables
	public Student1(int rollno, String name, float total) {
		
		this.rollno = rollno;
		this.name = name;
		this.total = total;
		name="Sunny";
		System.out.println("Localrollno="+rollno);
		System.out.println("Localname="+name);
		System.out.println("Localtotal="+total);
		System.out.println("rollno="+rollno);
		System.out.println("name="+this.name);
		System.out.println("total="+this.total);
	}

	void display(){
		System.out.println("rollno="+this.rollno);
		System.out.println("name="+this.name);
		System.out.println("total="+this.total);
		
	}
}
public class thisExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student1 obj=new Student1(1,"Kavita",78);
		obj.display();

	}

}
