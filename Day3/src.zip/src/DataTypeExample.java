
public class DataTypeExample {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*byte num1=9;
		byte num2=7;
		byte ans=(byte)(num1+num2);
		System.out.println(ans);*/
		
		//float num=56.9f;
		

	}

}
