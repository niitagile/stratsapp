import java.util.Scanner;

/*Loops--> repeat a block within a fixed range
 * for loop
 * 
 * for(startpoint;condition;inc/dec){
 * 
 * }
 * while is called as entry control loop
 * while(condition){
 * statements
 * }
 * do..whi
 */
public class LoopsExample {
public static void main(String[] args) {
		String name;
		Scanner scan=new Scanner(System.in);
		/*for(int count=1;count<=5;count++)//1..5 count++  means count=count+1
		{
		System.out.println("Enter name");
		name=scan.nextLine();
		System.out.println("name="+name);
		}*/
		
		int count=1;
		while(count<=5){
			System.out.println("Enter name");
			name=scan.nextLine();
			System.out.println("name="+name);
			count++;
		}
		
		
		
}
}
