class Calculator{
static	double	addition(double num1,double num2){
		return num1+num2;
	}

static	int	squre(int num){
			return num*num;
	}
	
	
}
public class MethodExample {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double ans=Calculator.addition(23, 67);
		System.out.println("sum="+ans);
		int sq=Calculator.squre(4);
		System.out.println("square="+sq);
		double pw=Math.pow(3, 5);
		System.out.println("power="+pw);

	}

}
