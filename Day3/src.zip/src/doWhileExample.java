import java.util.Scanner;

/*
 * do..while()--> exit control loop
 * 
 * 
 */
public class doWhileExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name;
		Scanner scan=new Scanner(System.in);
		int count=1;
		do{
		System.out.println("Enter name");
		name=scan.nextLine();
		System.out.println("name="+name);
		count++;
		}while(count<=5);

	}

}
/* Take values from user till user is not pressing n and calculate average of all nos.*/