package Inheritence;

class ParentC{
	int age=67;
	void show(int num){
		System.out.println("num="+num);
	}
	void display(){
		System.out.println(age);
	}
}
class ChildC extends ParentC{
	int age=90;
	@Override
	void show(int num){
		System.out.println("square="+num*num);
		//super.show(num);
		
	}
	@Override
	void display(){
		System.out.println(age);
	}
	void display_info(){}
	
}
public class OverridingExample3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ParentC obj=new ChildC();
		obj.show(5);
		//obj.age=89;
		obj.display();
		//obj.display_info();
		obj=new ParentC();
		obj.show(7);
	}

}
