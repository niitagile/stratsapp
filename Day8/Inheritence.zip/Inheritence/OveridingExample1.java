package Inheritence;
class ParentA{
	void show(int num){
		System.out.println("num="+num);
	}
}
class ChildA extends ParentA{
	@Override
	void show(int num){
		System.out.println("square="+num*num);
		super.show(num);
		
	}
}
public class OveridingExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChildA obj=new ChildA();
		obj.show(5);
	}

}
