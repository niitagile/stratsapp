package Inheritence;
//co-varient return type --Parent class and child class as return type
class ParentB{
	Number show(int num){
		System.out.println("num="+num);
		return num;
	}
}
class ChildB extends ParentB{
	@Override
	Integer show(int num){
		System.out.println("square="+num*num);
		super.show(num);
		return num;
	}
}
public class OverridingExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChildA obj=new ChildA();
		obj.show(5);
		
		
	}

}
