package Inheritence;
class Student extends Person{
	/*void display(){
		//System.out.println(id);
		//System.out.println(name);
	}*/
	void show(){
		setName("Isha");
		setId(145);
	}
	Student(int id, String name){
		
		super(id,name); //parameterized constructor of Person
	}
	Student(){}
	
}
public class InheritenceExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Student stud=new Student();
			//stud.setName("Lovely");
			//stud.setId(102);
			stud.show();
			
			
			Student s=new Student(178,"Kavita");
			System.out.println(s.getId());
			System.out.println(s.getName());
	}

}
