package Inheritence;
class Shape{
	void area(float a){}
	void area(float a, int p){}
	void area(int p, float a){}
	void area(int a){}
	//int area(float a){}error
}
public class OverloadingExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape s=new Shape();
		s.area(23);//method4
		s.area(7.8f,90);//method2

	}

}
